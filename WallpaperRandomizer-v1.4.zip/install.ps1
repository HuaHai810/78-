﻿# Wallpaper Randomizer - installer (script version, no compiled binary needed)
# Called by 安装.cmd. Installs the engine, registers the logon entries and
# runs the randomizer once. Everything is per-user, no admin rights required.

param([switch]$NoChange)

$ErrorActionPreference = 'Continue'

$SourceDir  = $PSScriptRoot
$EnginePath = Join-Path $SourceDir 'RandomWallpaper.ps1'
$AppDir     = Join-Path $env:LOCALAPPDATA 'WallpaperRandomizer'
$ScriptPath = Join-Path $AppDir 'RandomWallpaper.ps1'
$Settings   = Join-Path $AppDir 'settings.json'
$LogPath    = Join-Path $AppDir 'log.txt'
$TaskName   = 'WallpaperRandomizer'
$PowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Say($text) { Write-Host "  $text" }

Say ''
Say 'Wallpaper Randomizer'
Say '------------------------------------------------------------'

if (-not (Test-Path -LiteralPath $EnginePath)) {
    Say '[出错] 找不到 RandomWallpaper.ps1，请把压缩包完整解压后再运行。'
    exit 1
}

# ---------------------------------------------------------------- 1 文件
Say '[1/4] 释放程序文件…'
if (-not (Test-Path -LiteralPath $AppDir)) { New-Item -ItemType Directory -Force -Path $AppDir | Out-Null }
Copy-Item -LiteralPath $EnginePath -Destination $ScriptPath -Force
try { Unblock-File -LiteralPath $ScriptPath -ErrorAction SilentlyContinue } catch { }
if (-not (Test-Path -LiteralPath $Settings)) {
    @'
{
  "avoidLast": 5,
  "includeDefaultProjects": false,
  "includeAllSteamAccounts": false,
  "steamAccount": "auto"
}
'@ | Set-Content -LiteralPath $Settings -Encoding UTF8
}
Say "      程序目录: $AppDir"

# ---------------------------------------------------------------- 2 启动项
Say '[2/4] 设置开机自动换壁纸…'
$runCommand = "`"$PowerShell`" -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ScriptPath`""
$runOk = $false
try {
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'WallpaperRandomizer' -Value $runCommand -Type String -ErrorAction Stop
    Set-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'WallpaperRandomizer' -Value ([byte[]](2,0,0,0,0,0,0,0,0,0,0,0)) -Type Binary -ErrorAction SilentlyContinue
    $runOk = $true
} catch { Say ('      注册表启动项失败: ' + $_.Exception.Message) }

$startupDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
$startupOk = $false
try {
    if (-not (Test-Path -LiteralPath $startupDir)) { New-Item -ItemType Directory -Force -Path $startupDir | Out-Null }
    $vbs = @'
Option Explicit
Dim shell, target
Set shell = CreateObject("WScript.Shell")
target = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\WallpaperRandomizer\RandomWallpaper.ps1"
shell.Run "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & target & """", 0, False
'@
    Set-Content -LiteralPath (Join-Path $startupDir 'WallpaperRandomizer.vbs') -Value $vbs -Encoding ASCII
    Set-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' -Name 'WallpaperRandomizer.vbs' -Value ([byte[]](2,0,0,0,0,0,0,0,0,0,0,0)) -Type Binary -ErrorAction SilentlyContinue
    $startupOk = $true
} catch { Say ('      启动文件夹失败: ' + $_.Exception.Message) }

$taskOk = $false
try {
    $user = "$env:USERDOMAIN\$env:USERNAME"
    $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>$user</UserId><Delay>PT40S</Delay></LogonTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>$user</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><ExecutionTimeLimit>PT30M</ExecutionTimeLimit></Settings>
  <Actions Context="Author"><Exec><Command>$PowerShell</Command>
    <Arguments>-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "$ScriptPath"</Arguments></Exec></Actions>
</Task>
"@
    $xmlPath = Join-Path $env:TEMP 'wallpaper_randomizer_task.xml'
    [System.IO.File]::WriteAllText($xmlPath, $xml, [System.Text.Encoding]::Unicode)
    $out = & schtasks.exe /create /tn $TaskName /xml "$xmlPath" /f 2>&1
    Remove-Item -LiteralPath $xmlPath -Force -ErrorAction SilentlyContinue
    $taskOk = ($LASTEXITCODE -eq 0)
    if (-not $taskOk) { Say ('      计划任务失败（不影响使用）: ' + ($out -join ' ')) }
} catch { Say ('      计划任务失败（不影响使用）: ' + $_.Exception.Message) }
Say ("      注册表启动项: " + $(if ($runOk) { '成功' } else { '失败' }) + "   启动文件夹: " + $(if ($startupOk) { '成功' } else { '失败' }) + "   计划任务: " + $(if ($taskOk) { '成功' } else { '失败' }))

# ---------------------------------------------------------------- 3 辅助文件
Say '[3/4] 生成日常使用的小工具…'
$helpers = @{
    '立即换一张壁纸.cmd' = "@echo off`r`n`"$PowerShell`" -NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`" -Now`r`necho.`r`npause`r`n"
    '查看日志.cmd'       = "@echo off`r`nif exist `"$LogPath`" (start `"`" notepad.exe `"$LogPath`") else (echo 还没有日志文件，先换一张壁纸试试。& pause)`r`n"
}
foreach ($name in $helpers.Keys) {
    Set-Content -LiteralPath (Join-Path $AppDir $name) -Value $helpers[$name] -Encoding ASCII
}

# 程序目录里的卸载器就是压缩包里那个单文件版：即使 exe/安装脚本已经不在了也能用。
$standaloneUninstaller = Join-Path $SourceDir '卸载程序.cmd'
if (Test-Path -LiteralPath $standaloneUninstaller) {
    Copy-Item -LiteralPath $standaloneUninstaller -Destination (Join-Path $AppDir '卸载.cmd') -Force
} else {
    Set-Content -LiteralPath (Join-Path $AppDir '卸载.cmd') -Encoding ASCII -Value "@echo off`r`nschtasks /delete /tn $TaskName /f >nul 2>&1`r`nreg delete `"HKCU\Software\Microsoft\Windows\CurrentVersion\Run`" /v WallpaperRandomizer /f >nul 2>&1`r`ndel /f /q `"$startupDir\WallpaperRandomizer.vbs`" >nul 2>&1`r`nrd /s /q `"$AppDir`"`r`necho 已卸载。`r`npause`r`n"
}

# exe（图形界面/卸载用，图标已内嵌）和图标文件也放一份到程序目录
$exeSource = Join-Path $SourceDir 'WallpaperRandomizer.exe'
if (Test-Path -LiteralPath $exeSource) {
    Copy-Item -LiteralPath $exeSource -Destination (Join-Path $AppDir 'WallpaperRandomizer.exe') -Force
}
$icoSource = Join-Path $SourceDir '图标.ico'
if (Test-Path -LiteralPath $icoSource) {
    Copy-Item -LiteralPath $icoSource -Destination (Join-Path $AppDir '图标.ico') -Force
}

# ---------------------------------------------------------------- 4 测试
Say '[4/4] 现在换一张试试…'
if ($NoChange) {
    & $PowerShell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $ScriptPath -Preview | Out-Null
} else {
    & $PowerShell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $ScriptPath -Now | Out-Null
}
if (Test-Path -LiteralPath $LogPath) {
    Get-Content -LiteralPath $LogPath -Encoding UTF8 -ErrorAction SilentlyContinue | Select-Object -Last 4 | ForEach-Object { Say ('      ' + $_) }
}

Say ''
Say '完成！每次登录 Windows 后会自动从你自己的 Wallpaper Engine 壁纸库里随机换一张。'
Say '  想立刻换一张 : 双击程序目录里的「立即换一张壁纸.cmd」'
Say '  查看换了什么 : 「查看日志.cmd」'
Say '  不想要了     : 「卸载.cmd」'
Say "  程序目录     : $AppDir"
exit 0
