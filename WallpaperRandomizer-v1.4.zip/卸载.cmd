@echo off
setlocal
set "APPDIR=%LOCALAPPDATA%\WallpaperRandomizer"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WallpaperRandomizer.vbs"

echo 即将移除 Wallpaper Randomizer 的开机自启和程序文件：
echo   计划任务   : WallpaperRandomizer
echo   注册表启动项: HKCU\Software\Microsoft\Windows\CurrentVersion\Run\WallpaperRandomizer
echo   启动文件夹 : %STARTUP%
echo   程序目录   : %APPDIR%
echo.
set /p "ANSWER=确定继续? [Y/N] "
if /i not "%ANSWER%"=="Y" (
    echo 已取消。
    pause
    exit /b 0
)

schtasks /delete /tn "WallpaperRandomizer" /f >nul 2>&1 && echo 已移除计划任务。
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v WallpaperRandomizer /f >nul 2>&1 && echo 已移除注册表启动项。
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" /v WallpaperRandomizer /f >nul 2>&1
if exist "%STARTUP%" del /f /q "%STARTUP%" && echo 已移除启动文件夹项。
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder" /v "WallpaperRandomizer.vbs" /f >nul 2>&1
if exist "%APPDIR%" rd /s /q "%APPDIR%" && echo 已删除程序目录。

echo 完成。Wallpaper Engine 当前的壁纸不受影响。
pause
