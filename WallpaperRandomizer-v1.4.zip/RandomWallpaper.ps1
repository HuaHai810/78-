<#
    RandomWallpaper.ps1
    ------------------------------------------------------------------
    Picks one random wallpaper out of the wallpapers that are installed
    locally for Wallpaper Engine (Steam Workshop + your own local
    projects) and applies it through Wallpaper Engine's own command
    line interface.

    Typical use:
        RandomWallpaper.ps1                  wait for Wallpaper Engine, then apply
        RandomWallpaper.ps1 -Now             apply right away (no waiting)
        RandomWallpaper.ps1 -Preview         only show what would be picked
        RandomWallpaper.ps1 -List            list every installed wallpaper
        RandomWallpaper.ps1 -AvoidLast 10    never reuse the last 10 wallpapers
        RandomWallpaper.ps1 -MonitorIndex 1  apply to one specific monitor only

    Optional settings file (same folder as this script's data folder):
        %LOCALAPPDATA%\WallpaperRandomizer\settings.json
        {
            "wallpaperEngineDir": "E:\\SteamLibrary\\steamapps\\common\\wallpaper_engine",
            "avoidLast": 5,
            "includeDefaultProjects": false
        }

    Optional exclusion list (one entry per line, folder id or text):
        %LOCALAPPDATA%\WallpaperRandomizer\exclude.txt

    Exit codes: 0 = applied (or preview), 1 = nothing applied, 2 = no wallpapers found
#>

[CmdletBinding()]
param(
    [switch]$Now,
    [switch]$Preview,
    [switch]$List,
    [int]$AvoidLast = -1,
    [int]$WaitSeconds = 600,
    [int]$MonitorIndex = -1,
    [string]$WallpaperEngineDir,
    [switch]$IncludeDefaultProjects
)

$ErrorActionPreference = 'Stop'

$AppDir      = Join-Path $env:LOCALAPPDATA 'WallpaperRandomizer'
$LogFile     = Join-Path $AppDir 'log.txt'
$LogMirror   = ''
$StateFile   = Join-Path $AppDir 'state.json'
$ExcludeFile = Join-Path $AppDir 'exclude.txt'
$SettingsFile= Join-Path $AppDir 'settings.json'
$LockFile    = Join-Path $AppDir 'run.lock'
$ScriptVersion = '1.4'
$TaskName    = 'WallpaperEngine Random Wallpaper'
$StateKeep   = 30

function Write-Log {
    param([string]$Message, [switch]$Quiet)
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    if (-not $Quiet) { Write-Host $line }
    try {
        if (-not (Test-Path -LiteralPath $AppDir)) {
            New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
        }
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
        $lines = @(Get-Content -LiteralPath $LogFile -Encoding UTF8 -ErrorAction SilentlyContinue)
        if ($lines.Count -gt 400) {
            $lines[-300..-1] | Set-Content -LiteralPath $LogFile -Encoding UTF8
        }
    } catch { }
    if ($script:LogMirror) {
        try { Add-Content -LiteralPath $script:LogMirror -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    }
}

function Read-Settings {
    $settings = [pscustomobject]@{
        wallpaperEngineDir     = $null
        avoidLast              = 5
        includeDefaultProjects = $false
        logMirror              = $null
        includeAllSteamAccounts = $false
        steamAccount           = 'auto'
    }
    if (Test-Path -LiteralPath $SettingsFile) {
        try {
            $raw = Get-Content -LiteralPath $SettingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($name in @('wallpaperEngineDir', 'avoidLast', 'includeDefaultProjects', 'logMirror', 'includeAllSteamAccounts', 'steamAccount')) {
                if ($raw.PSObject.Properties[$name] -and $null -ne $raw.$name) {
                    $settings.$name = $raw.$name
                }
            }
        } catch {
            Write-Log "settings.json could not be read, using defaults: $($_.Exception.Message)"
        }
    }
    return $settings
}

function Get-SteamLibraryRoots {
    $steamPaths = New-Object System.Collections.Generic.List[string]
    foreach ($key in @('HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        try {
            $value = Get-ItemProperty -Path $key -ErrorAction Stop
            if ($value.InstallPath) { $steamPaths.Add([string]$value.InstallPath) }
        } catch { }
    }
    try {
        $value = Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop
        if ($value.SteamPath) { $steamPaths.Add([string]$value.SteamPath) }
    } catch { }

    $libraries = New-Object System.Collections.Generic.List[string]
    foreach ($steamPath in ($steamPaths | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $steamPath)) { continue }
        $libraries.Add($steamPath)
        $vdf = Join-Path $steamPath 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            $text = Get-Content -LiteralPath $vdf -Raw -ErrorAction SilentlyContinue
            foreach ($m in [regex]::Matches([string]$text, '"path"\s+"([^"]+)"')) {
                $path = $m.Groups[1].Value -replace '\\\\', '\'
                if (Test-Path -LiteralPath $path) { $libraries.Add($path) }
            }
        }
    }
    return ($libraries | Select-Object -Unique)
}

function Find-WallpaperEngine {
    param([string[]]$Libraries, [string]$Hint)
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($Hint) { $candidates.Add($Hint) }
    foreach ($lib in $Libraries) {
        $candidates.Add((Join-Path $lib 'steamapps\common\wallpaper_engine'))
    }
    foreach ($candidate in $candidates) {
        if (-not $candidate) { continue }
        if (Test-Path -LiteralPath (Join-Path $candidate 'wallpaper64.exe')) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return $null
}

function Get-SteamAccount {
    # Returns the Steam account whose subscriptions should be used.
    param([string]$SteamRoot, [string[]]$Libraries)

    $result = [pscustomobject]@{ Account = ''; SteamId32 = ''; Source = 'none' }
    $autoUser = ''
    try { $autoUser = [string](Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).AutoLoginUser } catch { }

    $vdf = $null
    foreach ($base in (@($SteamRoot) + @($Libraries))) {
        if (-not $base) { continue }
        $candidate = Join-Path $base 'config\loginusers.vdf'
        if (Test-Path -LiteralPath $candidate) { $vdf = $candidate; break }
    }
    if (-not $vdf) { return $result }

    $text = Get-Content -LiteralPath $vdf -Raw -ErrorAction SilentlyContinue
    if (-not $text) { return $result }

    $users = New-Object System.Collections.Generic.List[object]
    foreach ($m in [regex]::Matches([string]$text, '"(\d{17})"\s*\{([^}]*)\}')) {
        $body = $m.Groups[2].Value
        $stamp = 0
        $stampText = [regex]::Match($body, '"Timestamp"\s*"(\d+)"').Groups[1].Value
        if ($stampText) { $stamp = [int64]$stampText }
        $users.Add([pscustomobject]@{
            SID64     = [int64]$m.Groups[1].Value
            Account   = [regex]::Match($body, '"AccountName"\s*"([^"]*)"').Groups[1].Value
            AutoLogin = ([regex]::Match($body, '"AutoLogin"\s*"(\d)"').Groups[1].Value -eq '1')
            Timestamp = $stamp
        }) | Out-Null
    }
    if ($users.Count -eq 0) { return $result }

    $pick = @($users | Where-Object { $autoUser -and $_.Account -eq $autoUser } | Select-Object -First 1)
    if ($pick.Count -eq 0) { $pick = @($users | Where-Object { $_.AutoLogin } | Sort-Object Timestamp -Descending | Select-Object -First 1) }
    if ($pick.Count -eq 0) { $pick = @($users | Sort-Object Timestamp -Descending | Select-Object -First 1) }

    $chosen = $pick[0]
    $result.Account   = $chosen.Account
    $result.SteamId32 = [string]($chosen.SID64 - 76561197960265728)
    $result.Source    = 'loginusers.vdf'
    return $result
}

function Get-AcfSubscribedIds {
    # Workshop ids that are currently subscribed (Steam keeps this file up to date).
    param([string[]]$Libraries, [string]$SteamId32)

    $set = New-Object System.Collections.Generic.HashSet[string]
    $script:AcfMine = 0
    $script:AcfUnknown = 0
    $script:AcfOther = 0
    foreach ($lib in $Libraries) {
        $acf = Join-Path $lib 'steamapps\workshop\appworkshop_431960.acf'
        if (-not (Test-Path -LiteralPath $acf)) { continue }
        $text = Get-Content -LiteralPath $acf -Raw -ErrorAction SilentlyContinue
        if (-not $text) { continue }
        $start = $text.IndexOf('WorkshopItemDetails')
        if ($start -lt 0) { continue }
        $section = $text.Substring($start)
        # Walk "<id>" { ... } blocks with brace counting: some entries contain
        # nested values, which a simple regex would mis-parse.
        $pos = 0
        while ($pos -lt $section.Length) {
            $m = [regex]::Match($section.Substring($pos), '"(\d{6,})"\s*\{')
            if (-not $m.Success) { break }
            $id = $m.Groups[1].Value
            $braceStart = $pos + $m.Index + $m.Length - 1
            $depth = 0
            $cursor = $braceStart
            while ($cursor -lt $section.Length) {
                $ch = $section[$cursor]
                if ($ch -eq '{') { $depth++ }
                elseif ($ch -eq '}') {
                    $depth--
                    if ($depth -eq 0) { break }
                }
                $cursor++
            }
            $body = ''
            if ($cursor -gt $braceStart) { $body = $section.Substring($braceStart + 1, $cursor - $braceStart - 1) }
            $by = [regex]::Match($body, '"subscribedby"\s*"(\d+)"')
            if (-not $by.Success) {
                # Steam sometimes leaves the subscriber field empty although the
                # item is still subscribed, so keep those as well.
                $script:AcfUnknown++
                [void]$set.Add($id)
            } elseif ((-not $SteamId32) -or $by.Groups[1].Value -eq $SteamId32) {
                $script:AcfMine++
                [void]$set.Add($id)
            } else {
                $script:AcfOther++
            }
            $pos = $cursor + 1
        }
    }
    if ($set.Count -eq 0) { return $null }
    return $set
}

function Get-WallpaperList {
    param([string]$WeDir, [string[]]$Libraries, [switch]$IncludeDefault, $AllowedWorkshopIds)

    $workshopRoots = New-Object System.Collections.Generic.List[string]
    foreach ($lib in $Libraries) {
        $workshopRoots.Add((Join-Path $lib 'steamapps\workshop\content\431960')) | Out-Null
    }
    $localRoots = New-Object System.Collections.Generic.List[string]
    if ($WeDir) {
        $localRoots.Add((Join-Path $WeDir 'projects\myprojects')) | Out-Null
        if ($IncludeDefault) { $localRoots.Add((Join-Path $WeDir 'projects\defaultprojects')) | Out-Null }
    }

    $items = New-Object System.Collections.Generic.List[object]
    $seen  = New-Object System.Collections.Generic.HashSet[string]
    $script:WorkshopFound = 0
    $script:WorkshopSkipped = 0

    foreach ($root in $workshopRoots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($dir in (Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
            $script:WorkshopFound++
            if ($AllowedWorkshopIds -and -not $AllowedWorkshopIds.Contains($dir.Name)) {
                $script:WorkshopSkipped++
                continue
            }
            if (-not $seen.Add($dir.FullName)) { continue }
            $projectFile = Join-Path $dir.FullName 'project.json'
            if (-not (Test-Path -LiteralPath $projectFile)) { continue }

            $json = $null
            try { $json = Get-Content -LiteralPath $projectFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
            if (-not $json) { continue }

            $type = ''
            if ($json.PSObject.Properties['type'] -and $json.type) { $type = [string]$json.type }
            if ($type -eq 'preset') { continue }

            # Published scene wallpapers reference "scene.json" while only the
            # compiled "scene.pkg" is shipped, so accept either of the two.
            $hasContent = (Test-Path -LiteralPath (Join-Path $dir.FullName 'scene.pkg')) -or
                          (Test-Path -LiteralPath (Join-Path $dir.FullName 'scene.json'))
            if (-not $hasContent -and $json.PSObject.Properties['file'] -and $json.file) {
                $hasContent = Test-Path -LiteralPath (Join-Path $dir.FullName ([string]$json.file))
            }
            if (-not $hasContent) { continue }

            $title = $dir.Name
            if ($json.PSObject.Properties['title'] -and $json.title) { $title = [string]$json.title }

            $items.Add([pscustomobject]@{
                Id        = $dir.Name
                Title     = $title
                Type      = $type
                Project   = $projectFile
                Directory = $dir.FullName
            })
        }
    }

    foreach ($root in $localRoots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($dir in (Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
            if (-not $seen.Add($dir.FullName)) { continue }
            $projectFile = Join-Path $dir.FullName 'project.json'
            if (-not (Test-Path -LiteralPath $projectFile)) { continue }
            $json = $null
            try { $json = Get-Content -LiteralPath $projectFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
            if (-not $json) { continue }
            $type = ''
            if ($json.PSObject.Properties['type'] -and $json.type) { $type = [string]$json.type }
            if ($type -eq 'preset') { continue }
            $hasContent = (Test-Path -LiteralPath (Join-Path $dir.FullName 'scene.pkg')) -or
                          (Test-Path -LiteralPath (Join-Path $dir.FullName 'scene.json'))
            if (-not $hasContent -and $json.PSObject.Properties['file'] -and $json.file) {
                $hasContent = Test-Path -LiteralPath (Join-Path $dir.FullName ([string]$json.file))
            }
            if (-not $hasContent) { continue }
            $title = $dir.Name
            if ($json.PSObject.Properties['title'] -and $json.title) { $title = [string]$json.title }
            $items.Add([pscustomobject]@{
                Id        = $dir.Name
                Title     = $title
                Type      = $type
                Project   = $projectFile
                Directory = $dir.FullName
            })
        }
    }
    return $items
}

function Get-ExcludedItems {
    if (-not (Test-Path -LiteralPath $ExcludeFile)) { return @() }
    return @(Get-Content -LiteralPath $ExcludeFile -Encoding UTF8 -ErrorAction SilentlyContinue |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') })
}

function Get-RecentPicks {
    if (-not (Test-Path -LiteralPath $StateFile)) { return @() }
    try {
        $state = Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.PSObject.Properties['lastUsed'] -and $state.lastUsed) { return @($state.lastUsed) }
    } catch { }
    return @()
}

function Add-RecentPick {
    param([string]$Path)
    $recent = @(Get-RecentPicks)
    $recent = @(@($Path) + ($recent | Where-Object { $_ -ne $Path }))
    if ($recent.Count -gt $StateKeep) { $recent = $recent[0..($StateKeep - 1)] }
    $json = [pscustomobject]@{
        lastUsed       = $recent
        lastAppliedUtc = (Get-Date).ToUniversalTime().ToString('o')
    } | ConvertTo-Json -Depth 3
    if (-not (Test-Path -LiteralPath $AppDir)) { New-Item -ItemType Directory -Force -Path $AppDir | Out-Null }
    [System.IO.File]::WriteAllText($StateFile, $json, (New-Object System.Text.UTF8Encoding($false)))
}

function Get-LastAppliedUtc {
    if (-not (Test-Path -LiteralPath $StateFile)) { return $null }
    try {
        $state = Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.PSObject.Properties['lastAppliedUtc'] -and $state.lastAppliedUtc) {
            return [datetime]::Parse([string]$state.lastAppliedUtc).ToUniversalTime()
        }
    } catch { }
    return $null
}

function Get-SessionId {
    # Identifies the current logon session, so that only one automatic change
    # happens per logon no matter how many auto-start entries fire.
    $explorer = Get-Process -Name explorer -ErrorAction SilentlyContinue | Sort-Object StartTime | Select-Object -First 1
    if ($explorer -and $explorer.StartTime) {
        return 'ls' + $explorer.StartTime.ToString('yyyyMMddHHmmss')
    }
    try {
        return 'boot' + ((Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime).ToString('yyyyMMddHHmmss')
    } catch { }
    return ''
}

function Get-CurrentWallpaperDirectory {
    # Folder of the wallpaper Wallpaper Engine is showing right now.
    param([string]$WeDir)
    $block = Get-SelectedWallpaperBlock -WeDir $WeDir
    if (-not $block) { return $null }
    $match = [regex]::Match($block, '"file"\s*:\s*"([^"]+)"')
    if (-not $match.Success) { return $null }
    $file = $match.Groups[1].Value -replace '/', '\'
    try { return (Split-Path -Parent $file) } catch { return $null }
}

function Set-SessionMarker {
    if (-not $SessionMarker) { return }
    try {
        if (-not (Test-Path -LiteralPath $AppDir)) { New-Item -ItemType Directory -Force -Path $AppDir | Out-Null }
        [System.IO.File]::WriteAllText($SessionMarker, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), (New-Object System.Text.UTF8Encoding($false)))
        Get-ChildItem -LiteralPath $AppDir -Filter 'applied_*.mark' -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } |
            ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    } catch { }
}

function Get-SelectedWallpaperBlock {
    param([string]$WeDir)
    $configPath = Join-Path $WeDir 'config.json'
    if (-not (Test-Path -LiteralPath $configPath)) { return '' }
    $text = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    if (-not $text) { return '' }
    $start = $text.IndexOf('"wallpaperconfig"')
    if ($start -lt 0) { return '' }
    $end = $text.IndexOf('"wallpaperconfigrecent"')
    if ($end -lt $start) { $end = [Math]::Min($text.Length, $start + 4000) }
    return $text.Substring($start, $end - $start)
}

function Send-WallpaperCommand {
    param([string]$WeDir, [string]$ProjectFile, [int]$Monitor)

    $exeName = 'wallpaper64.exe'
    $running64 = Get-Process -Name 'wallpaper64' -ErrorAction SilentlyContinue
    $running32 = Get-Process -Name 'wallpaper32' -ErrorAction SilentlyContinue
    if (-not $running64 -and $running32) { $exeName = 'wallpaper32.exe' }

    $exePath = Join-Path $WeDir $exeName
    if (-not (Test-Path -LiteralPath $exePath)) { return $false }

    $arguments = @('-control', 'openWallpaper', '-file', ('"{0}"' -f $ProjectFile))
    if ($Monitor -ge 0) { $arguments += @('-monitor', [string]$Monitor) }

    try {
        $proc = Start-Process -FilePath $exePath -ArgumentList $arguments -WindowStyle Hidden -PassThru
        if ($proc) { $null = $proc.WaitForExit(30000) }
        return $true
    } catch {
        Write-Log "Could not start the Wallpaper Engine control command: $($_.Exception.Message)"
        return $false
    }
}

function Confirm-WallpaperApplied {
    param([string]$WeDir, [string]$Directory, [int]$TimeoutSeconds = 25)
    $needle = ($Directory -replace '\\', '/')
    for ($i = 0; $i -lt $TimeoutSeconds; $i++) {
        Start-Sleep -Seconds 1
        $block = Get-SelectedWallpaperBlock -WeDir $WeDir
        if ($block -and $block.Contains($needle)) { return $true }
    }
    return $false
}

function Test-DesktopLooksBlank {
    # Some scenes draw only part of their content right after being applied.
    # Detect an (almost) black desktop so the wallpaper can be reloaded.
    param([double]$MaxBlackFraction = 0.20)
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
        if ($bounds.Width -lt 100 -or $bounds.Height -lt 100) { return $false }
        $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($bounds.Left, $bounds.Top, 0, 0, $bmp.Size)
        $g.Dispose()
        $step = 8
        $black = 0
        $total = 0
        for ($y = 0; $y -lt $bmp.Height; $y += $step) {
            for ($x = 0; $x -lt $bmp.Width; $x += $step) {
                $c = $bmp.GetPixel($x, $y)
                $luma = 0.2126 * $c.R + 0.7152 * $c.G + 0.0722 * $c.B
                if ($luma -lt 8) { $black++ }
                $total++
            }
        }
        $bmp.Dispose()
        if ($total -eq 0) { return $false }
        $fraction = $black / $total
        Write-Log ("Desktop check: {0:P0} of the screen is nearly black." -f $fraction)
        return ($fraction -gt $MaxBlackFraction)
    } catch {
        Write-Log ("Desktop check skipped: " + $_.Exception.Message)
        return $false
    }
}

# ---------------------------------------------------------------- main

$lockTaken = $false

try {
    $settings = Read-Settings
    if ($settings.PSObject.Properties['logMirror'] -and $settings.logMirror) { $script:LogMirror = [string]$settings.logMirror }
    if ($AvoidLast -lt 0) { $AvoidLast = [int]$settings.avoidLast }
    if (-not $WallpaperEngineDir) { $WallpaperEngineDir = [string]$settings.wallpaperEngineDir }
    if (-not $IncludeDefaultProjects -and $settings.includeDefaultProjects) { $IncludeDefaultProjects = [bool]$settings.includeDefaultProjects }

    # ---------------------------------------------------------- start log
    $parentName = 'unknown'
    try {
        $self = Get-CimInstance Win32_Process -Filter ("ProcessId={0}" -f $PID) -ErrorAction Stop
        if ($self) {
            $parentProc = Get-CimInstance Win32_Process -Filter ("ProcessId={0}" -f $self.ParentProcessId) -ErrorAction SilentlyContinue
            if ($parentProc) { $parentName = $parentProc.Name }
        }
    } catch { }
    $sessionLabel = 'none'
    $sessionId = Get-SessionId
    if ($sessionId) {
        $sessionLabel = $sessionId
        $SessionMarker = Join-Path $AppDir ('applied_' + $sessionId + '.mark')
    }
    Write-Log ("Start | v{0} | pid={1} parent={2} | session={3} | Now={4} Preview={5} List={6}" -f $ScriptVersion, $PID, $parentName, $sessionLabel, [bool]$Now, [bool]$Preview, [bool]$List)

    # ---------------------------------------------------------- run lock
    $interactiveRun = ($Now -or $Preview -or $List)
    if (-not $interactiveRun) {
        $lockIsFresh = $false
        if (Test-Path -LiteralPath $LockFile) {
            $age = (Get-Date) - (Get-Item -LiteralPath $LockFile).LastWriteTime
            if ($age.TotalMinutes -lt 2) { $lockIsFresh = $true }
        }
        if ($lockIsFresh) {
            Write-Log 'Another run started within the last 2 minutes, skipping this duplicate start.'
            exit 0
        }
        try {
            $handle = [System.IO.File]::Open($LockFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
            $handle.Close()
            $lockTaken = $true
        } catch {
            Write-Log 'Could not take the run lock, skipping this start.'
            exit 0
        }
    }

    $libraries = @(Get-SteamLibraryRoots)
    $weDir = Find-WallpaperEngine -Libraries $libraries -Hint $WallpaperEngineDir
    if (-not $weDir) {
        Write-Log 'Wallpaper Engine installation not found. Set "wallpaperEngineDir" in settings.json.'
        exit 1
    }

    # ------------------------------------------------- wallpaper pool filter
    # Only wallpapers that the Steam account in use actually has installed.
    $allowedIds = $null
    if (-not $settings.includeAllSteamAccounts) {
        $steamRoot = $null
        try { $steamRoot = [string](Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction Stop).InstallPath } catch { }
        $account = Get-SteamAccount -SteamRoot $steamRoot -Libraries $libraries
        $wantedAccount = [string]$settings.steamAccount
        if ($wantedAccount -and $wantedAccount -ne 'auto' -and $wantedAccount -ne $account.SteamId32 -and $wantedAccount -ne $account.Account) {
            $account = [pscustomobject]@{ Account = $wantedAccount; SteamId32 = $wantedAccount; Source = 'settings.json' }
        }
        $allowedIds = Get-AcfSubscribedIds -Libraries $libraries -SteamId32 $account.SteamId32
        if ($allowedIds) {
            Write-Log ("Steam account: {0} ({1}) | your subscribed wallpapers: {2} ({3} with your account id, {4} without subscriber info; {5} belong to another account)" -f $account.Account, $account.SteamId32, $allowedIds.Count, $script:AcfMine, $script:AcfUnknown, $script:AcfOther)
        } else {
            Write-Log ("Steam account {0} ({1}) could not be matched in the workshop list, using every wallpaper on disk." -f $account.Account, $account.SteamId32)
        }
    }

    $all = @(Get-WallpaperList -WeDir $weDir -Libraries $libraries -IncludeDefault:$IncludeDefaultProjects -AllowedWorkshopIds $allowedIds)
    if ($allowedIds) {
        Write-Log ("Pool: {0} wallpapers ({1} local, skipped {2} workshop folders that belong to another account or were unsubscribed)" -f $all.Count, (@($all | Where-Object { $_.Id -notmatch '^\d+$' }).Count), $script:WorkshopSkipped)
    }
    if ($all.Count -eq 0) {
        Write-Log "No installed wallpapers found below $weDir."
        exit 2
    }

    # ---------------------------------------------------- duplicate guards
    # Every logon several entries fire (scheduled task, Run key, startup folder)
    # and they do not necessarily overlap, so remember what was already done
    # for this logon session and for the last few minutes.
    if (-not $interactiveRun) {
        if ($SessionMarker -and (Test-Path -LiteralPath $SessionMarker)) {
            $when = ''
            try { $when = [System.IO.File]::ReadAllText($SessionMarker).Trim() } catch { }
            Write-Log ("Already changed the wallpaper this logon session ({0}), skipping this duplicate start." -f $when)
            exit 0
        }
        # Only when the logon session cannot be identified do we fall back to a
        # short time window, so that a quick reboot still gets a new wallpaper.
        if (-not $SessionMarker) {
            $lastApplied = Get-LastAppliedUtc
            if ($lastApplied) {
                $ageMinutes = ((Get-Date).ToUniversalTime() - $lastApplied).TotalMinutes
                if ($ageMinutes -ge 0 -and $ageMinutes -lt 2) {
                    Write-Log ("No logon session id available and a wallpaper was applied {0:N1} minutes ago, skipping this duplicate start." -f $ageMinutes)
                    exit 0
                }
            }
        }
    }

    $excluded = Get-ExcludedItems
    if ($excluded.Count -gt 0) {
        $all = @($all | Where-Object {
            $item = $_
            $hit = $false
            foreach ($pattern in $excluded) {
                if ($item.Id -like $pattern -or $item.Directory -like "*$pattern*" -or $item.Title -like "*$pattern*") { $hit = $true; break }
            }
            -not $hit
        })
        if ($all.Count -eq 0) {
            Write-Log 'Every wallpaper is excluded by exclude.txt.'
            exit 2
        }
    }

    if ($List) {
        Write-Log ("Installed wallpapers: {0} (Wallpaper Engine: {1})" -f $all.Count, $weDir) -Quiet
        $all | Sort-Object Title | ForEach-Object { '{0,-12} {1,-8} {2}' -f $_.Id, $_.Type, $_.Title }
        exit 0
    }

    $recent = @(Get-RecentPicks)
    $candidates = $all
    if ($AvoidLast -gt 0 -and $all.Count -gt ($AvoidLast + 1)) {
        $recentSubset = @($recent | Select-Object -First $AvoidLast)
        $filtered = @($all | Where-Object { $recentSubset -notcontains $_.Project })
        if ($filtered.Count -gt 0) { $candidates = $filtered }
    }

    # Never hand out the wallpaper that is already on screen.
    $currentDir = Get-CurrentWallpaperDirectory -WeDir $weDir
    if ($currentDir) {
        $others = @($candidates | Where-Object { $_.Directory -ne $currentDir })
        if ($others.Count -gt 0) {
            $candidates = $others
        }
    }

    $chosen = @($candidates) | Get-Random

    if ($Preview) {
        Write-Log ("Would apply: {0}  [{1}]  ({2} candidates out of {3})" -f $chosen.Title, $chosen.Type, $candidates.Count, $all.Count) -Quiet
        $chosen | Format-List Id, Title, Type, Project
        exit 0
    }

    if (-not $Now) {
        Write-Log ("Waiting for Wallpaper Engine (up to {0}s) ..." -f $WaitSeconds)
        $waitStart = Get-Date
        $deadline = (Get-Date).AddSeconds($WaitSeconds)
        $running = $false
        while ((Get-Date) -lt $deadline) {
            if (Get-Process -Name 'wallpaper64', 'wallpaper32' -ErrorAction SilentlyContinue) { $running = $true; break }
            Start-Sleep -Seconds 3
        }
        if (-not $running) {
            Write-Log 'Wallpaper Engine is not running yet, nothing was changed. It will start itself and the next run will pick up.'
            exit 1
        }
        Write-Log ("Wallpaper Engine is running (waited {0:N0}s)." -f ((Get-Date) - $waitStart).TotalSeconds)
        Start-Sleep -Seconds 5
    }

    # Wallpaper Engine needs a few seconds after launch before it accepts
    # control commands, so retry, with a longer pause before the last try.
    $applied = $false
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        if (-not (Send-WallpaperCommand -WeDir $weDir -ProjectFile $chosen.Project -Monitor $MonitorIndex)) {
            Write-Log 'Command could not be sent.'
            break
        }
        if (Confirm-WallpaperApplied -WeDir $weDir -Directory $chosen.Directory) { $applied = $true; break }
        if ($attempt -lt 4) {
            $pause = 8
            if ($attempt -eq 3) { $pause = 60 }
            Write-Log ("Attempt {0} not confirmed yet, retrying in {1}s." -f $attempt, $pause)
            Start-Sleep -Seconds $pause
        }
    }

    if ($applied) {
        Add-RecentPick -Path $chosen.Project
        Set-SessionMarker
        Write-Log ("Applied: {0}  [{1}]  {2}" -f $chosen.Title, $chosen.Type, $chosen.Id)
        # Wallpaper Engine may still be finishing its own start-up and could
        # restore an older wallpaper afterwards, so look once more.
        Start-Sleep -Seconds 6
        if (-not (Confirm-WallpaperApplied -WeDir $weDir -Directory $chosen.Directory -TimeoutSeconds 5)) {
            Write-Log 'Wallpaper Engine switched away again, applying once more.'
            if (Send-WallpaperCommand -WeDir $weDir -ProjectFile $chosen.Project -Monitor $MonitorIndex) {
                if (Confirm-WallpaperApplied -WeDir $weDir -Directory $chosen.Directory -TimeoutSeconds 20) {
                    Write-Log 'Re-applied and confirmed.'
                } else {
                    Write-Log 'Re-apply was not confirmed.'
                }
            }
        }
        # Scenes sometimes come up as a black screen on their very first load,
        # so look at the desktop and reload the same wallpaper once if needed.
        if (-not $Preview -and -not $List) {
            Start-Sleep -Seconds 4
            if (Test-DesktopLooksBlank) {
                Write-Log 'Desktop is almost black, reloading the same wallpaper once.'
                if (Send-WallpaperCommand -WeDir $weDir -ProjectFile $chosen.Project -Monitor $MonitorIndex) {
                    Start-Sleep -Seconds 12
                    if (Confirm-WallpaperApplied -WeDir $weDir -Directory $chosen.Directory -TimeoutSeconds 10) {
                        Write-Log 'Reloaded and confirmed.'
                    } else {
                        Write-Log 'Reload was not confirmed.'
                    }
                }
            }
        }
        exit 0
    }

    Write-Log ("Not confirmed by Wallpaper Engine: {0}  [{1}]" -f $chosen.Title, $chosen.Id)
    exit 1
} catch {
    Write-Log ("Error: {0}" -f $_.Exception.Message)
    Write-Log ("At: {0}" -f $_.ScriptStackTrace)
    exit 1
} finally {
    if ($lockTaken) { Remove-Item -LiteralPath $LockFile -Force -ErrorAction SilentlyContinue }
}
